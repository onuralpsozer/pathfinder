
const int buzzerPin=10; // buzzer pin connected to arduino
int i,j,f; // variables

void startUpBuzzer() {
  digitalWrite(buzzerPin, HIGH);
  delay(250);
  digitalWrite(buzzerPin, LOW); 
  }

void openingSound() {
  analogWrite(buzzerPin,90);
  delay(200);
  analogWrite(buzzerPin,0);
  delay(100);
  analogWrite(buzzerPin,250);
  delay(250);
  analogWrite(buzzerPin,0);
  }

void closingSound() {
  analogWrite(buzzerPin,250);
  delay(200);
  analogWrite(buzzerPin,0);
  delay(100);
  analogWrite(buzzerPin,90);
  delay(250);
  analogWrite(buzzerPin,0);
  }

void navigatingSound() {
  analogWrite(buzzerPin,200);
  delay(150);
  analogWrite(buzzerPin,0);
  delay(100);
  analogWrite(buzzerPin,150);
  delay(150);
  analogWrite(buzzerPin,0);
  delay(100);
  analogWrite(buzzerPin,100);
  delay(150);
  analogWrite(buzzerPin,0);
  }

void batteryFinish() {
  for(i=250;i>=0;i=i-30){
    analogWrite(buzzerPin,i);
    delay(180);
    analogWrite(buzzerPin,0);
    delay(100);
    }
    analogWrite(buzzerPin,20);
    delay(650);
    analogWrite(buzzerPin,0);
  }

void battery20Under() {
  for(j=0;j<5;j++){
    analogWrite(buzzerPin,250);
    delay(120);
    analogWrite(buzzerPin,0);
    delay(50);
    }
  }

void bluetoothMapped() {
    analogWrite(buzzerPin,250);
    delay(140);
    analogWrite(buzzerPin,0);
    delay(60);
    analogWrite(buzzerPin,250);
    delay(140);
    analogWrite(buzzerPin,0);
  }

void bluetoothCutOff() {
    analogWrite(buzzerPin,180);
    delay(100);
    analogWrite(buzzerPin,0);
    delay(60);
    analogWrite(buzzerPin,80);
    delay(100);
    analogWrite(buzzerPin,0);
    delay(60);
    analogWrite(buzzerPin,240);
    delay(100);
    analogWrite(buzzerPin,0);
  }
void chargeFull() {
  for(f=40;f<=250;f=f+40){
    analogWrite(buzzerPin,f);
    delay(180);
    analogWrite(buzzerPin,0);
    delay(100);
    }
    analogWrite(buzzerPin,240);
    delay(450);
    analogWrite(buzzerPin,0);
  }
