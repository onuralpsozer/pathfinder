bool IsPathfinder = false;

uint8_t UltrasonicSensorData = 0; // First state initializations
uint8_t TouchButton1State = 0;
uint8_t TouchButton2State = 0;
uint8_t batteryLevelPercent = 0;

int upperBoundary = 150 ; // Ultrasonic Sensor data read upper boundary
int lowerBoundary = 50 ; // Ultrasonic Sensor data read lower boundary

int rightMotorPin = 5; // Right motor speed control pin
int leftMotorPin = 6; // Left motor speed control pin

int Touchbutton1Pin = 2;
int Touchbutton2Pin = 3;

int buzzerPin= 4;
int batteryLevelPin = A1; 

int ultrasonicDataPin = 7; // Ultrasonic sensor data read pin

void startUpBuzzer(){  // when the device stars buzzer beeps for 0.1 second
  
  digitalWrite(buzzerPin, HIGH);
  delay(100);
  digitalWrite(buzzerPin, LOW);
}

void pathfinderInitialization( void ){ // Input or output initialization of the sensors, motors and buttons
  pinMode(ultrasonicDataPin, INPUT);
  pinMode(rightMotorPin, OUTPUT);
  pinMode(leftMotorPin, OUTPUT);
}

void buttonBuzzerInitialization(){
  pinMode(Touchbutton1Pin, INPUT);
  pinMode(Touchbutton2Pin, INPUT);
  pinMode(buzzerPin, OUTPUT);
 }

void blink1(){ 
 TouchButton1State = 0x01;
}
void blink2(){
  TouchButton2State = 0x01;
}

uint8_t getUltrasonicData(){ // the conversion of the data we get from sensor to cm
  int distance = ( pulseIn(ultrasonicDataPin, HIGH) / 147 ) * 2.54;
  if(distance > 250){
    distance = 250;
  }
  if (distance < 15) {
    distance = 15;
  }
  return  distance;
}

uint8_t batteryLevel(){ // the conversion of the data we get from the batteryLevelPin to percentage
  int batteryLevelValue = 0;
  batteryLevelValue = analogRead(batteryLevelPin); 
  batteryLevelPercent = ((batteryLevelValue * (5.0 / 1023.0))-3)*100.0/1.2 ;
  
  if ( batteryLevelPercent > 100.00 ) { // the values higher than 100 and lower than 0 are not included in the process
    batteryLevelPercent = 100.00 ;
  }
  else if ( batteryLevelPercent < 0.00){
    batteryLevelPercent = 0.00 ;
  }
  
  return (batteryLevelPercent);
}

void runPathfinder( void ){ 
  int distance = getUltrasonicData();  // Pathfinder algorithm have 50 to 150 cm working area and giving motors power
  Serial.print(distance);
  Serial.println();
  if(distance < lowerBoundary){
    analogWrite(rightMotorPin,0);
    analogWrite(leftMotorPin, 0);
   // Serial.print(distance);
   // Serial.println();
  }else if(upperBoundary > distance){
    analogWrite(rightMotorPin,255 );
    analogWrite(leftMotorPin, 255);
   // Serial.print(distance);
   // Serial.println();
    delay(100);
    analogWrite(rightMotorPin,0);
    analogWrite(leftMotorPin, 0);
  }
 
}

void Drive(int Type, int PWM){  // Motor or buzzer drive function
  analogWrite(Type, PWM);
}

void StopDriving(int Type ){
  analogWrite(Type, 0);
}

uint8_t readButtonState(int Type){ 
  // yapılacak
}

