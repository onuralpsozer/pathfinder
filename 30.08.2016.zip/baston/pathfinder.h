/*  Copyright (c) 2014, Nordic Semiconductor ASA
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.  
 *  
 */


/*  Our project is based on a smart blind cane. We made a system which included
 *  a ultrasonic sensor , two vibration motors , a buzzer , a RedBearLab BLE Shield
 *  (nRF 8001 chip) , a Adafruit PowerBoost 500 Lipo Battery Shield and two push buttons.
 *  There are two phases of this project. 
 *  
 *  First phase includes two vibration motors and a utrasonic sensor. In this phase
 *  the receieved ultrasonic sensor data converted to cm and for 50-150 cm
 *  distance the two vibrations motors are fully powered. Ultrasonic sensor
 *  works only in this zone and outside of it the vibration motors stop working.
 *  Ultrasonic sensor measures the distances between 15-250 cm.
 *  
 *  The second phase of this project is the bluetooth side. In this phase we used the RBL
 *  Bluetooth Shield which uses Bluetooth 4.0 and nRF 8001 chip. For the bluetooth side 
 *  we use write without response, read and notify commands in the nRF chip. We created a
 *  services header file (services.h) from nRF Go Studio and included this header file in 
 *  the project. There are two services in this header file and one service is for 
 *  battery level and one service for the cane commands. Below the cane service, there are
 *  six characteristics. The first one is the algorithm on/off characteristic, second
 *  one is the two motors's on/off and motors' power characteristic, third one is 
 *  buzeer on/off and power characteristic forth is the ultrasonic sensor data send 
 *  characteristic. The fifth and the sixth characteristics are the button characteristics.
 *  And below the battery level service there is a battery level characteristic. 
 */

/*  This code is an open-source code.
 *  To contact with the developers of this code you can e-mail to
 *  Onuralp Sözer     : onuralpsozer@gmail.com
 *  Kürşat Eren Uzun  : kursaterenuzun@gmail.com
 *  Mert Kaya         : kkayamertt@gmail.com
 *  Aykut Arabacıoğlu : aykutarabaciogluu@gmail.com
 *  Mehmetali Baysal  : mehmetaliibaysal@gmail.com
 */    

/*  The libraries for the watch dog timer are included  */     

/* This header file includes all of the tasks which have been called in 
the bluetooth.h and the initializations which have called from the baston.ino file */

bool IsPathfinder = false;

volatile uint8_t UltrasonicSensorData = 0; // First state initializations
volatile uint8_t batteryLevelPercent = 0;

int Time;
int motorState = 0;
unsigned long lastTime = 0;
unsigned long newTime;

int upperBoundary = 150 ; // Ultrasonic Sensor data read upper boundary
int lowerBoundary = 50 ; // Ultrasonic Sensor data read lower boundary

volatile int rightMotorPin = 5; // Right motor speed control pin
volatile int leftMotorPin = 6; // Left motor speed control pin

volatile int buzzerPin= A0;
volatile int batteryLevelPin = A1; 

volatile int buttonPin1 = 2;
volatile int buttonPin2 = 3;

volatile uint8_t Button1State = 0x00;
volatile uint8_t Button2State = 0x00;

int ultrasonicDataPin = 7; // Ultrasonic sensor data read pin



void pathfinderInitialization( void ){ // Input or output initialization
  pinMode(ultrasonicDataPin, INPUT);
  pinMode(rightMotorPin, OUTPUT);
  pinMode(leftMotorPin, OUTPUT);
}

void buttonBuzzerInitialization(){
  pinMode(buttonPin1, INPUT);
  pinMode(buttonPin2, INPUT);
  pinMode(buzzerPin, OUTPUT);
 }

void buttonInterrupt1(){
  Button1State = digitalRead(buttonPin1);
  Serial.println(Button1State);
}
void buttonInterrupt2(){
  Button2State = digitalRead(buttonPin2);
  Serial.println(Button2State);
}

uint8_t getUltrasonicData(){
  return ( pulseIn(ultrasonicDataPin, HIGH) / 147 ) * 2.54; // Ultrasonic data to cm 
}

void Drive(int Type, int PWM){  // Motor or buzzer drive function
  analogWrite(Type, PWM);
}

void StopDriving(int Type ){
  analogWrite(Type, 0);
}

void startUpBuzzer(){
  Drive(buzzerPin, 200);
  delay(250);
  StopDriving(buzzerPin); 
}

uint8_t batteryLevel(){     // This function indicates battery level
  int batteryLevelValue = 0;
  batteryLevelValue = analogRead(batteryLevelPin);
  batteryLevelPercent = ((batteryLevelValue * (5.0 / 1023.0))-3)*100.0/1.2 ;
  
  if ( batteryLevelPercent > 100 ) {
    batteryLevelPercent = 100 ;
  }
  else if ( batteryLevelPercent < 0){
    batteryLevelPercent = 0 ;
  }
  
  return (batteryLevelPercent);
}

void runPathfinder( void ){     // This function is obstacle detection function
  newTime = millis();
  Time = newTime - lastTime;
  int distance = getUltrasonicData();  // Pathfinder algorithm 50 to 150 cm working area and giving motors power
  //Serial.print(distance);
  //Serial.println();
  if(upperBoundary > distance && distance >lowerBoundary){
    //analogWrite(motorPin,255 );
    //delay(200);
    //analogWrite(motorPin,0);
   if(Time > 200){
     if(motorState == 1){
      StopDriving(rightMotorPin);
      StopDriving(leftMotorPin);
      motorState = 0;
     }
     else{
      Drive(rightMotorPin,255);
      Drive(leftMotorPin,255);
      motorState = 1;
     }
     lastTime = newTime;
  }
  }
   if(distance < lowerBoundary || distance > upperBoundary){
    StopDriving(rightMotorPin);
    StopDriving(leftMotorPin);
  }
}


